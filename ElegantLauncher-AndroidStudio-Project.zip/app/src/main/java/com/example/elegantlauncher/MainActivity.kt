package com.example.elegantlauncher

import android.app.Activity
import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaController
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weather: TextView
    private lateinit var musicTitle: TextView
    private lateinit var musicArtist: TextView
    private var drawerOpen = false
    private var gaming = false
    private val handler = Handler(Looper.getMainLooper())
    private val apps = mutableListOf<android.content.pm.ApplicationInfo>()
    private val clockTick = object : Runnable {
        override fun run() {
            if (::clock.isInitialized) {
                clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 23, 20)
        window.navigationBarColor = Color.rgb(16, 23, 20)
        root = FrameLayout(this)
        root.addView(AnimatedBackdrop(this), FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(32), dp(24), dp(20))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        showHome()
        handler.post(clockTick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(clockTick)
        super.onDestroy()
    }

    private fun showHome() {
        drawerOpen = false
        content.removeAllViews()
        content.addView(label("E L E G A N T", 12f, 0xFFB8C9BE.toInt()).apply {
            letterSpacing = 0.22f
        })
        val spacer = View(this)
        content.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        clock = label("09:41", 64f, Color.WHITE).apply { typeface = android.graphics.Typeface.create("sans-serif-light", 0) }
        date = label("Senin, 8 November", 15f, 0xFFD1DAD4.toInt())
        content.addView(clock)
        content.addView(date)
        content.addView(space(22))

        val weatherCard = card()
        val weatherRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        weather = label("☁  Cuaca belum diatur", 15f, Color.WHITE)
        weatherRow.addView(weather, LinearLayout.LayoutParams(0, -2, 1f))
        val weatherButton = smallButton("ATUR")
        weatherButton.setOnClickListener {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=cuaca+hari+ini"))
            startActivity(i)
        }
        weatherRow.addView(weatherButton)
        weatherCard.addView(weatherRow)
        content.addView(weatherCard)

        content.addView(space(18))
        content.addView(label("Aplikasi favorit", 17f, Color.WHITE))
        val favorites = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val defaults = listOf("Telepon" to Intent(Intent.ACTION_DIAL), "Pesan" to Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            "Kamera" to Intent("android.media.action.IMAGE_CAPTURE"), "Pengaturan" to Intent(Settings.ACTION_SETTINGS))
        defaults.forEach { (name, intent) ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(12), dp(8), dp(12)) }
            val icon = TextView(this).apply {
                text = when (name) { "Telepon" -> "☎"; "Pesan" -> "✉"; "Kamera" -> "◎"; else -> "⚙" }
                textSize = 27f; gravity = Gravity.CENTER
                background = rounded(0xFF293A32.toInt(), 22f)
                setTextColor(Color.WHITE)
            }
            item.addView(icon, LinearLayout.LayoutParams(dp(58), dp(58)))
            item.addView(label(name, 11f, 0xFFE0E8E2.toInt()).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0) })
            item.setOnClickListener { launchIntent(intent) }
            favorites.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(favorites)
        content.addView(space(12))

        val music = card()
        music.addView(label("SEDANG DIPUTAR", 10f, 0xFFB8C9BE.toInt()))
        musicTitle = label("Kontrol musik", 16f, Color.WHITE)
        musicArtist = label("Aktifkan akses notifikasi untuk membaca sesi musik", 11f, 0xFFCAD5CE.toInt())
        music.addView(musicTitle)
        music.addView(musicArtist)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        listOf("⏮" to -1, "▶ / ⏸" to 0, "⏭" to 1).forEach { (txt, action) ->
            val b = smallButton(txt)
            b.setOnClickListener { controlMusic(action) }
            controls.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) })
        }
        music.addView(space(8)); music.addView(controls)
        val access = smallButton("IZINKAN KONTROL MUSIK")
        access.setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        music.addView(space(6)); music.addView(access)
        content.addView(music)

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0) }
        val drawer = smallButton("SEMUA APLIKASI  ↑")
        drawer.setOnClickListener { showDrawer() }
        val game = smallButton(if (gaming) "MODE GAMING: ON" else "MODE GAMING")
        game.setOnClickListener { toggleGaming(game) }
        bottom.addView(drawer, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(8) })
        bottom.addView(game, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(bottom)
        content.addView(space(4))
        content.addView(label("Tekan “Semua aplikasi” untuk membuka daftar aplikasi", 10f, 0xFF9EADA3.toInt()).apply { gravity = Gravity.CENTER })
        animateIn()
    }

    private fun showDrawer() {
        drawerOpen = true
        content.removeAllViews()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = label("Aplikasi", 30f, Color.WHITE)
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val close = smallButton("TUTUP")
        close.setOnClickListener { showHome() }
        header.addView(close)
        content.addView(header)
        val search = EditText(this).apply {
            hint = "Cari aplikasi"
            setSingleLine(true)
            textSize = 15f
            setTextColor(Color.WHITE); setHintTextColor(0xFFB8C9BE.toInt())
            background = rounded(0xFF293A32.toInt(), 18f)
            setPadding(dp(16), 0, dp(16), 0)
        }
        content.addView(space(14)); content.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = true }
        scroll.addView(grid)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun populate(filter: String) {
            grid.removeAllViews()
            val pm = packageManager
            val list = apps.filter { pm.getApplicationLabel(it).toString().contains(filter, true) }
                .sortedBy { pm.getApplicationLabel(it).toString().lowercase(Locale.getDefault()) }
            list.forEach { app ->
                val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(12), dp(4), dp(12)) }
                val iv = ImageView(this).apply { setImageDrawable(pm.getApplicationIcon(app)); scaleType = ImageView.ScaleType.FIT_CENTER }
                item.addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)))
                item.addView(label(pm.getApplicationLabel(app).toString(), 10f, Color.WHITE).apply {
                    gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                })
                item.setOnClickListener { pm.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) } }
                item.setOnLongClickListener {
                    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                    startActivity(i); true
                }
                grid.addView(item, GridLayout.LayoutParams().apply { width = 0; height = dp(100); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
            }
        }
        apps.clear()
        @Suppress("DEPRECATION")
        apps.addAll(packageManager.getInstalledApplications(0).filter { packageManager.getLaunchIntentForPackage(it.packageName) != null })
        populate("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        animateIn()
    }

    private fun toggleGaming(button: Button) {
        gaming = !gaming
        button.text = if (gaming) "MODE GAMING: ON" else "MODE GAMING"
        Toast.makeText(this, if (gaming) "Mode gaming aktif: tampilan lebih fokus." else "Mode gaming nonaktif.", Toast.LENGTH_SHORT).show()
        // This starter mode is a launcher-side profile; it does not change system performance or DND.
    }

    private fun controlMusic(action: Int) {
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, MusicNotificationListener::class.java)
            val sessions = manager.getActiveSessions(component)
            val controller = sessions.firstOrNull()
            if (controller == null) {
                Toast.makeText(this, "Belum ada sesi musik aktif. Putar musik dan izinkan akses notifikasi.", Toast.LENGTH_LONG).show()
                return
            }
            val controls = controller.transportControls
            when (action) {
                -1 -> controls.skipToPrevious()
                0 -> if (controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) controls.pause() else controls.play()
                1 -> controls.skipToNext()
            }
            musicTitle.text = controller.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Musik"
            musicArtist.text = controller.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: "Sedang diputar"
        } catch (_: SecurityException) {
            Toast.makeText(this, "Aktifkan akses notifikasi untuk kontrol musik.", Toast.LENGTH_LONG).show()
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        } catch (_: Exception) {
            Toast.makeText(this, "Kontrol musik belum tersedia di perangkat ini.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchIntent(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Aplikasi tidak tersedia", Toast.LENGTH_SHORT).show() }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(0xCC24332C.toInt(), 22f)
    }
    private fun smallButton(text: String): Button = Button(this).apply {
        this.text = text; textSize = 10f; isAllCaps = false
        setTextColor(Color.WHITE); background = rounded(0xFF526C61.toInt(), 16f)
        stateListAnimator = null
    }
    private fun label(text: String, size: Float, color: Int): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
    }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius.toInt()).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun animateIn() {
        content.startAnimation(AlphaAnimation(0f, 1f).apply { duration = 350; interpolator = DecelerateInterpolator() })
    }

    private class AnimatedBackdrop(context: Context) : View(context) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        private val h = Handler(Looper.getMainLooper())
        private val tick = object : Runnable {
            override fun run() { phase += 0.008f; invalidate(); h.postDelayed(this, 40) }
        }
        init { h.post(tick) }
        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val ht = height.toFloat()
            val shift = (kotlin.math.sin(phase.toDouble()).toFloat() + 1f) / 2f
            paint.shader = android.graphics.LinearGradient(0f, 0f, w, ht,
                intArrayOf(Color.rgb(13, 21, 18), Color.rgb(30 + (shift * 8).toInt(), 49, 40), Color.rgb(12, 19, 17)),
                null, android.graphics.Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, ht, paint)
            paint.shader = null
            paint.color = 0x183E6854
            canvas.drawCircle(w * (0.8f + 0.05f * kotlin.math.sin(phase.toDouble()).toFloat()), ht * 0.25f, w * 0.42f, paint)
        }
    }
}
