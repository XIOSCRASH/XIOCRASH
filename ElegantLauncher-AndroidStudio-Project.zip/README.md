# Elegant Launcher (Android Studio)

Starter project for a native Android home-screen launcher.

## Included
- Android HOME/launcher activity (select it as the default Home app)
- Minimal dark-green animated gradient wallpaper background
- Clock and date
- App drawer with search; tap an icon to launch, long-press to open app info
- Favorite shortcuts (Phone, Messages, Camera, Settings)
- Launcher-side gaming profile toggle
- Music transport controls through Android MediaSessionManager (requires Notification Access)
- Weather card shortcut that opens a weather search (live weather API is not configured)

## Build
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder (`ElegantLauncher`) in Android Studio.
3. Let Gradle sync finish.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Set as default launcher
Install the APK, press Home, and choose **Elegant Launcher**. You can also change it in Android Settings > Apps > Default apps > Home app.

## Enable music controls
Open the launcher, tap **IZINKAN KONTROL MUSIK**, and enable notification access for Elegant Launcher. Start playback in a media app, then use the previous/play-pause/next controls.

## Notes / limitations
- This is a buildable starter project, not a precompiled APK.
- Weather is a shortcut, not live in-app weather. A weather provider/API key and location permission would be needed for live forecasts.
- The animated background is drawn by the launcher while it is open; it is not a system-wide Android live wallpaper service.
- Custom icon packs, persistent user-editable favorites, and OEM-specific gaming/performance controls are not implemented yet.
- Android may limit app visibility depending on OS version and device policy. The project declares QUERY_ALL_PACKAGES for the app-drawer use case.
